﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace FirstTryScrolling
{
    class Troll
    {
        public Texture2D _image;
        public Vector2 _position;
        public Color _color;
        public Rectangle hitbox;
        bool updown = false;
        public BulletClass _bullet;
        public int Health = 30;
        TimeSpan _bulletDelay;
        public List<BulletClass> Bullets;
        TimeSpan _delayControl;
        public Troll(Texture2D image, Vector2 position, Color color, BulletClass bullet)
        {
            _delayControl = TimeSpan.Zero;
            _bulletDelay = new TimeSpan(0, 0, 0, 1);
            _image = image;
            _position = position;
            _color = color;
            _bullet = bullet;
            Bullets = new List<BulletClass>();
            hitbox = new Rectangle((int)_position.X,(int) _position.Y, _image.Width, _image.Height);
        }
        public virtual void Update(GameTime gameTime, List<BulletClass> Bullet)
        {
            if (_delayControl > _bulletDelay)
            {
                _delayControl = TimeSpan.Zero;
                Vector2 bulletSpawn = new Vector2( _position.X + (_image.Width - _bullet._image.Width) / 2, _position.Y);
                Bullets.Add(new BulletClass(_bullet._image, bulletSpawn, _bullet._color, _bullet._speed));
                //where we shoot a bullet
            }
            foreach (var B in Bullets)
            {
                B.Update();
            }
            if (updown == false)
            {
                _position.Y -= 10;
            }
            if (updown == true)
            {
                _position.Y += 10;
            }
            if (_position.Y <= 0)
            {
                updown = true;
            }
            if (_position.Y >= 400)
            {
                updown = false;
            }
            _delayControl += gameTime.ElapsedGameTime;
            
            hitbox = new Rectangle((int)_position.X, (int)_position.Y, _image.Width, _image.Height);
        }

        public void Draw(SpriteBatch spriteBatch, SpriteFont s)
        {
            //spriteBatch.Draw(Game1.pixel, hitbox, Color.Blue);
            for (int i = 0; i < Bullets.Count; i++)
            {
                Bullets[i].Draw(spriteBatch);
            }
            spriteBatch.Draw(_image, _position, _color);
            spriteBatch.DrawString(s, ("Health:" + Health), new Vector2(_position.X + (_image.Width /4) ,_position.Y - 25), Color.Black);
            
        }
    }
}

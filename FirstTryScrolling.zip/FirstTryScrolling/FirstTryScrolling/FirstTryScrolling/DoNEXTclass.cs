﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirstTryScrolling
{
    class DoNEXTclass
    {
        //1.add checkpoint flag
        //2.add flying monster that goes up and down use a list
        //3.make flag story bout how blob has to collect all da flags to be da best ninja in flagtopia
        //

        //
        //
        //
        //
        //Make a bool to control if fire comes out of jetpack when trumpcont jump is true it shoes when up arrow is pressed make blocks after enemies
        //
        //
        //
        //add gameover screeen
        //add pause
        //label stuff
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
    }
}

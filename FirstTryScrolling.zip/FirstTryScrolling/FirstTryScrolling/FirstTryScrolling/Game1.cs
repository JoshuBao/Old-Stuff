using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace FirstTryScrolling
{

    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Player player;
        MouseState ms;
        KeyboardState ks;
        KeyboardState lastks;
        SpriteFont font;
        Sprite mouse;
        int movementAmount = 0;

        //BUNCH OF SPRITES HERE 

        Sprite Back1;
        Sprite Back2;
        Sprite Back3;
        Sprite Back4;
        Sprite Back5;
        Sprite Back6;
        Sprite Back7;
        Sprite Back8;

        BulletClass Trollbullet;

        List<BulletClass> PlayerBullets;

        bool ShowLightning = false;

        Sprite background;
        Sprite background2;
        List<Sprite> Blocks;
        List<Sprite> Signs;
        Texture2D ImgBlock;
        Texture2D ImgPol;


        //bools for signs and steff
        bool Showsmsg = false;
        bool Showsmsg1 = false;
        bool Showmsg2 = false;
        bool Showsmsg3 = false;

        Texture2D WpolImg;
        Lightning lightning;
        Lightning Whitepic;
        //sprite blocks
        Sprite blocks;
        Sprite block2;
        Sprite block3;
        Sprite block4;
        Sprite block5;
        Sprite block6;
        Sprite block7;
        Sprite block8;
        Sprite block9;
        //sprite blocks2
        Sprite blocks10;
        Sprite blocks11;
        Sprite blocks12;
        Sprite blocks13;
        Sprite blocks14;
        Sprite blocks15;

        //sprite blocks3
        Sprite blocks16;
        Sprite blocks17;
        Sprite blocks18;
        Sprite blocks19;
        Sprite blocks20;

        //sprite pits of LAVA
        Sprite pol;
        Sprite pol2;
        Sprite pol3;
        Sprite pol4;
        Sprite pol5;
        Sprite pol6;

        Sprite JetPackPowerUp;

        List<Sprite> WPol;
        List<Sprite> Pol;

        bool Trumpjumpcount = false;

        bool GameStopped = false;

        List<BulletClass> Bullet;
        Sprite Smsg;
        Sprite Smsg1;
        Sprite Smsg2;
        Sprite Smsg3;
        Sprite Oldman1;
        //flag stuff very cool and important
        List<Sprite> Flags;
        Sprite Flag1;
        // troll stuf
        List<Troll> Trolls;
        Troll troll1;
        Troll troll2;
        Troll troll3;
        bool RIGHT = false;
        bool LEFT = true;
        public static Texture2D pixel;
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }


        protected override void Initialize()
        {
            graphics.PreferredBackBufferWidth = 900;
            graphics.PreferredBackBufferHeight = 700;

            graphics.ApplyChanges();

            base.Initialize();
        }


        protected override void LoadContent()
        {

            spriteBatch = new SpriteBatch(GraphicsDevice);
            pixel = Content.Load<Texture2D>("Thing");
            PlayerBullets = new List<BulletClass>();
            BulletClass potadoge = new BulletClass(Content.Load<Texture2D>("potadoge"), new Vector2(-0, -100), Color.White, new Vector2(20, 0));
            //PlayerBullets.Add(potadoge);
            player = new Player(Content.Load<Texture2D>("BLOB"), new Vector2(350, 400), Color.White, potadoge);
            //sprite stuffs
            mouse = new Sprite(Content.Load<Texture2D>("Sign"), new Vector2(0, 0), Color.White);
            Texture2D backimage = Content.Load<Texture2D>("TRY2");
            background = new Sprite(Content.Load<Texture2D>("TRY#"), new Vector2(0, 200), Color.White);
            background2 = new Sprite(backimage, new Vector2(backimage.Width, 200), Color.White);
            ImgBlock = (Content.Load<Texture2D>("block"));

            Whitepic = new Lightning(Content.Load<Texture2D>("WhitePic"), new Vector2(0), Color.White);
            lightning = new Lightning(Content.Load<Texture2D>("Lightning"), new Vector2(0, 0), Color.White);


            Back1 = new Sprite(Content.Load<Texture2D>("TRY#"), new Vector2(0, 200), Color.White);
            Back2 = new Sprite(backimage, new Vector2(4096, 200), Color.White);
            Back3 = new Sprite(Content.Load<Texture2D>("TRY#"), new Vector2(8192, 200), Color.White);
            Back4 = new Sprite(backimage, new Vector2(12288, 200), Color.White);
            Back5 = new Sprite(Content.Load<Texture2D>("TRY#"), new Vector2(16384, 200), Color.White);
            Back6 = new Sprite(backimage, new Vector2(20480, 200), Color.White);
            Back7 = new Sprite(Content.Load<Texture2D>("TRY#"), new Vector2(24576, 200), Color.White);
            Back8 = new Sprite(backimage, new Vector2(28672, 200), Color.White);

            Signs = new List<Sprite>();
            Texture2D SignsIMG = (Content.Load<Texture2D>("Sign"));

            Sprite sign = new Sprite(SignsIMG, new Vector2(929, 440), Color.White);
            Sprite sign2 = new Sprite(SignsIMG, new Vector2(487, 335), Color.White);
            Sprite sign3 = new Sprite(SignsIMG, new Vector2(2440, 440), Color.White);

            Oldman1 = new Sprite(Content.Load<Texture2D>("Oldman1"), new Vector2(8000, 450), Color.White);

            Signs.Add(sign);
            Signs.Add(sign2);
            Signs.Add(sign3);
            Signs.Add(Oldman1);

            //SMSG sprites

            Smsg = new Sprite(Content.Load<Texture2D>("smsg1"), new Vector2(0, 0), Color.White);
            Smsg1 = new Sprite(Content.Load<Texture2D>("smsg2"), new Vector2(0, 0), Color.White);
            Smsg2 = new Sprite(Content.Load<Texture2D>("smsg3"), new Vector2(0, 0), Color.White);
            Smsg3 = new Sprite(Content.Load<Texture2D>("Oldmanmsg1"), new Vector2(0, 0), Color.White);


            //flag steff
            Flags = new List<Sprite>();
            Flag1 = new Sprite(Content.Load<Texture2D>("CheckPointFlag"), new Vector2(7700, 440), Color.White);


            //flag list steff
            Flags.Add(Flag1);



            //sprites for blocks
            blocks = new Sprite(ImgBlock, new Vector2(484, 403), Color.White);
            block2 = new Sprite(ImgBlock, new Vector2(826, 256), Color.White);
            block3 = new Sprite(ImgBlock, new Vector2(1200, 300), Color.White);
            block4 = new Sprite(ImgBlock, new Vector2(1500, 400), Color.White);
            block5 = new Sprite(ImgBlock, new Vector2(1700, 200), Color.White);
            block6 = new Sprite(ImgBlock, new Vector2(2000, 300), Color.White);
            block7 = new Sprite(ImgBlock, new Vector2(3000, 400), Color.White);
            block8 = new Sprite(ImgBlock, new Vector2(3400, 300), Color.White);
            block9 = new Sprite(ImgBlock, new Vector2(3800, 250), Color.White);

            //sprites for blocks 2


            blocks10 = new Sprite(ImgBlock, new Vector2(4200, 300), Color.White);
            blocks11 = new Sprite(ImgBlock, new Vector2(5000, 150), Color.White);
            blocks12 = new Sprite(ImgBlock, new Vector2(5400, 250), Color.White);
            blocks13 = new Sprite(ImgBlock, new Vector2(5900, 350), Color.White);
            blocks14 = new Sprite(ImgBlock, new Vector2(6500, 200), Color.White);
            blocks15 = new Sprite(ImgBlock, new Vector2(7500, 200), Color.White);

            //sprites for blocks 3

            blocks16 = new Sprite(ImgBlock, new Vector2(11000, 200), Color.White);
            blocks17 = new Sprite(ImgBlock, new Vector2(11500, 400), Color.White);
            blocks18 = new Sprite(ImgBlock, new Vector2(11900, 300), Color.White);
            blocks19 = new Sprite(ImgBlock, new Vector2(12300, 250), Color.White);
            blocks20 = new Sprite(ImgBlock, new Vector2(12800, 400), Color.White);




            Blocks = new List<Sprite>();
            Blocks.Add(blocks);
            Blocks.Add(block2);
            Blocks.Add(block3);
            Blocks.Add(block4);
            Blocks.Add(block5);
            Blocks.Add(block6);
            Blocks.Add(block7);
            Blocks.Add(block8);
            Blocks.Add(block9);
            //2
            Blocks.Add(blocks10);
            Blocks.Add(blocks11);
            Blocks.Add(blocks12);
            Blocks.Add(blocks13);
            Blocks.Add(blocks14);
            Blocks.Add(blocks15);
            //3
            Blocks.Add(blocks16);
            Blocks.Add(blocks17);
            Blocks.Add(blocks18);
            Blocks.Add(blocks19);
            Blocks.Add(blocks20);

            //power ups

            JetPackPowerUp = new Sprite(Content.Load<Texture2D>("Jetpack Powerup"), new Vector2(blocks15._position.X + 50, blocks15._position.Y - 60), Color.White);

            //MORE TROLL STUFF
            Trollbullet = new BulletClass(Content.Load<Texture2D>("Troll Bomb"), new Vector2(-100000, -320), Color.White, new Vector2(0, 10));
            Trolls = new List<Troll>();
            troll1 = new Troll(Content.Load<Texture2D>("Troll"), new Vector2(8500, 0), Color.White, Trollbullet);
            troll2 = new Troll(Content.Load<Texture2D>("Troll"), new Vector2(9000, 900), Color.White, Trollbullet);
            troll3 = new Troll(Content.Load<Texture2D>("Troll"), new Vector2(9500, 0), Color.White, Trollbullet);
            Troll troll4 = new Troll(Content.Load<Texture2D>("Troll"), new Vector2(10400, 900), Color.White, Trollbullet);
            Troll troll5 = new Troll(Content.Load<Texture2D>("Troll"), new Vector2(10900, 0), Color.White, Trollbullet);


            Trolls.Add(troll1);
            Trolls.Add(troll2);
            Trolls.Add(troll3);
            Trolls.Add(troll4);
            Trolls.Add(troll5);
            // sprites for Pol

            Pol = new List<Sprite>();
            ImgPol = (Content.Load<Texture2D>("POL"));
            pol2 = new Sprite(ImgPol, new Vector2(2500, 650), Color.White);
            pol = new Sprite(ImgPol, new Vector2(1000, 650), Color.White);
            pol3 = new Sprite(ImgPol, new Vector2(4600, 650), Color.White);
            pol4 = new Sprite(ImgPol, new Vector2(4800, 650), Color.White);
            pol5 = new Sprite(ImgPol, new Vector2(6990, 650), Color.White);
            pol6 = new Sprite(ImgPol, new Vector2(7100, 650), Color.White);
            Sprite pol7 = new Sprite(ImgPol, new Vector2(7290, 650), Color.White);
            Pol.Add(pol);
            Pol.Add(pol2);
            Pol.Add(pol3);
            Pol.Add(pol4);
            Pol.Add(pol5);
            Pol.Add(pol6);
            Pol.Add(pol7);
            WPol = new List<Sprite>();
            WpolImg = (Content.Load<Texture2D>("PolWIMG"));
            Sprite wpol = new Sprite(WpolImg, new Vector2(pol._position.X, 500), Color.White);
            Sprite wpol2 = new Sprite(WpolImg, new Vector2(pol2._position.X, 500), Color.White);
            Sprite wpol3 = new Sprite(WpolImg, new Vector2(pol3._position.X, 500), Color.White);
            Sprite wpol4 = new Sprite(WpolImg, new Vector2(pol4._position.X, 500), Color.White);
            Sprite wpol5 = new Sprite(WpolImg, new Vector2(pol5._position.X, 500), Color.White);
            Sprite wpol6 = new Sprite(WpolImg, new Vector2(pol6._position.X, 500), Color.White);
            Sprite wpol7 = new Sprite(WpolImg, new Vector2(pol7._position.X, 500), Color.White);
            WPol.Add(wpol);
            WPol.Add(wpol2);
            WPol.Add(wpol3);
            WPol.Add(wpol4);
            WPol.Add(wpol5);
            WPol.Add(wpol6);
            WPol.Add(wpol7);


            Bullet = new List<BulletClass>();
            Bullet.Add(Trollbullet);


            font = Content.Load<SpriteFont>("MOUSE");
        }

        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }


        protected override void Update(GameTime gameTime)
        {
            if (GameStopped == false)
            {

                if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                    this.Exit();
                ms = Mouse.GetState();

                //Update123
                //Trolls take damage from player
                for (int f = 0; f < Trolls.Count; f++)
                {
                    for (int i = 0; i < PlayerBullets.Count; i++)
                    {
                        if (PlayerBullets[i]._position.X <= 0)
                        {
                            PlayerBullets.Remove(PlayerBullets[i]);
                            break;
                        }
                        if (PlayerBullets[i]._position.X >= 900)
                        {
                            PlayerBullets.Remove(PlayerBullets[i]);
                            break;
                        }
                        if (PlayerBullets[i].hitbox.Intersects(Trolls[f].hitbox))
                        {
                            Trolls[f].Health -= 7;
                            PlayerBullets.Remove(PlayerBullets[i]);
                            break;
                        }
                    }
                    //Player Takes Damage from trolls
                    for (int e = 0; e < Trolls.Count; e++)
                    {

                        for (int j = 0; j < Trolls[e].Bullets.Count; j++)
                        {
                            if (Trolls[e].Bullets[j].hitbox.Intersects(player.hitbox))
                            {
                                player.Health -= 8;
                                Trolls[e].Bullets.Remove(Trolls[e].Bullets[j]);
                                break;
                            }
                        }
                    }
                }
                // trolls can die now
                for (int i = 0; i < Trolls.Count; i++)
                {
                    if (Trolls[i].Health <= 0)
                    {
                        Trolls.Remove(Trolls[i]);
                        break;
                    }
                }
                //players can die too...
                if (player.Health <= 0)
                {
                    player.lives--;
                    player.Health = 100;
                    if (player.lives <= 0)
                    {
                        GameStopped = true;
                        //show game over screen here!!!!
                    }
                }

                //Player bullets are destroyed when they hit blocks
                for (int i = 0; i < Bullet.Count; i++)
                {
                    Bullet[i].Update();
                }
                for (int i = 0; i < Blocks.Count; i++)
                {
                    for (int e = 0; e < PlayerBullets.Count; e++)
                    {
                        if (PlayerBullets[e].hitbox.Intersects(Blocks[i].hitbox))
                        {
                            PlayerBullets.Remove(PlayerBullets[e]);
                            break;
                        }
                    }
                }

                //Condition made for flying
                if (Trumpjumpcount)
                {
                    player.jumpCount = 0;
                }
                mouse._position.X = ms.X;
                mouse._position.Y = ms.Y;
                // lastks = Keyboard.GetState();

                player.Update();

                ks = Keyboard.GetState();

                lightning._position.Y = player._position.Y - 460;
                if (ks.IsKeyDown(Keys.Up) && lastks.IsKeyUp(Keys.Up))
                {
                    player.moveUp();
                }
                int touchCounter = 0;

                if (player.hitbox.Intersects(Signs[0].hitbox))
                {
                    Showsmsg = true;
                }
                else
                {
                    Showsmsg = false;
                }
                if (player.hitbox.Intersects(Signs[1].hitbox))
                {
                    Showsmsg1 = true;
                }
                else
                {
                    Showsmsg1 = false;
                }
                if (player.hitbox.Intersects(Signs[2].hitbox))
                {
                    Showmsg2 = true;
                }
                else
                {
                    Showmsg2 = false;
                }
                if (player.hitbox.Intersects(Signs[3].hitbox))
                {
                    Showsmsg3 = true;
                }
                else
                {
                    Showsmsg3 = false;
                }
                for (int i = 0; i < WPol.Count; i++)
                {
                    if (player.BHitbox.Intersects(WPol[i].hitbox))
                    {
                        player.touchpit = true;
                        if (player._position.Y >= 616)
                        {
                            player.jumpCount = 2;
                        }
                    }
                    else
                    {
                        touchCounter++;
                        if (touchCounter == WPol.Count)
                        {
                            player.touchpit = false;
                        }
                    }

                    if (player._position.X >= WPol[i]._position.X + WPol[i]._image.Width || player.touchpit == true)
                    {
                        //player._position.Y = WPol[i]._position.X + WPol[i]._image.Width;
                    }
                    if (player._position.X <= WPol[i]._position.X || player.touchpit == true)
                    {
                        //player._position.Y = WPol[i]._position.Y;
                    }


                }
                for (int i = 0; i < Trolls.Count; i++)
                {
                    Trolls[i].Update(gameTime, Bullet);
                }

                //BULLET.......
                for (int i = 0; i < Bullet.Count; i++)
                {
                    Bullet[i].Update();

                }
                for (int i = 0; i < PlayerBullets.Count; i++)
                {
                    PlayerBullets[i]._position += PlayerBullets[i]._speed;
                    PlayerBullets[i].Update();

                }

                if (ks.IsKeyDown(Keys.A) && lastks.IsKeyUp(Keys.L))
                {
                    ShowLightning = true;
                }
                else
                {
                    ShowLightning = false;
                }

                if (background._position.X <= -background._image.Width)
                {
                    background._position.X = background._image.Width;

                }
                if (background2._position.X <= -background2._image.Width)
                {
                    background2._position.X = background2._image.Width;
                }
                //hitbox if statements
                for (int i = 0; i < Blocks.Count; i++)
                {
                    if (Blocks[i].hitbox.Intersects(player.THitbox))
                    {
                        player._position.Y = Blocks[i]._position.Y + player._image.Height;
                        player.jumpSpeed = 0;
                        player.jumpCount = int.MaxValue;
                    }
                    if (Blocks[i].hitbox.Intersects(player.BHitbox))
                    {
                        player._position.Y = Blocks[i]._position.Y - player._image.Height;
                        player.jumpCount = 0;
                    }

                    if (Blocks[i].hitbox.Intersects(player.LHitbox))
                    {
                        float blockSpeed = Blocks[i]._position.X + Blocks[i]._image.Width - player._position.X;
                        LEFT = true;
                        for (int e = 0; e < Blocks.Count; e++)
                        {
                            Blocks[e]._position.X -= blockSpeed;
                        }
                        background._position.X -= blockSpeed;
                        background2._position.X -= blockSpeed;

                    }
                    else
                    {
                        LEFT = false;
                    }
                    if (Blocks[i].hitbox.Intersects(player.RHitbox))
                    {
                        float blockSpeed = Blocks[i]._position.X - player._image.Width - player._position.X;
                        RIGHT = true;
                        for (int e = 0; e < Blocks.Count; e++)
                        {
                            Blocks[e]._position.X -= blockSpeed;
                        }
                        background._position.X -= blockSpeed;
                        background2._position.X -= blockSpeed;

                    }
                    else
                    {
                        RIGHT = false;
                    }
                }
                if (ks.IsKeyDown(Keys.Space) && lastks.IsKeyUp(Keys.Space))
                {
                    if (player.effect == SpriteEffects.None)
                    {

                        PlayerBullets.Add(new BulletClass(player._Bullet._image, player._position, player._Bullet._color, player._Bullet._speed));
                        for (int i = 0; i < PlayerBullets.Count; i++)
                        {
                            PlayerBullets[i]._position -= PlayerBullets[i]._speed;

                        }
                    }
                    else
                    {
                        PlayerBullets.Add(new BulletClass(player._Bullet._image, player._position, player._Bullet._color, -player._Bullet._speed));
                        for (int i = 0; i < PlayerBullets.Count; i++)
                        {
                            PlayerBullets[i]._position -= PlayerBullets[i]._speed;

                        }
                    }

                }
                if (LEFT == false)
                {
                    if (ks.IsKeyDown(Keys.Right))
                    {
                        background._position.X -= 10;
                        background2._position.X -= 10;
                        player.effect = SpriteEffects.None;
                        movementAmount++;
                        for (int i = 0; i < Pol.Count; i++)
                        {
                            Pol[i]._position.X -= 10;
                            Pol[i].hitbox = new Rectangle((int)Pol[i]._position.X, (int)Pol[i]._position.Y, Pol[i]._image.Width, Pol[i]._image.Height);
                        }
                        for (int i = 0; i < Blocks.Count; i++)
                        {
                            Blocks[i]._position.X -= 10;
                            Blocks[i].hitbox = new Rectangle((int)Blocks[i]._position.X, (int)Blocks[i]._position.Y, Blocks[i]._image.Width, Blocks[i]._image.Height);
                        }
                        for (int i = 0; i < WPol.Count; i++)
                        {
                            WPol[i]._position.X -= 10;
                            WPol[i].hitbox = new Rectangle((int)WPol[i]._position.X, (int)WPol[i]._position.Y, WPol[i]._image.Width, WPol[i]._image.Height);
                        }
                        for (int i = 0; i < Signs.Count; i++)
                        {
                            Signs[i]._position.X -= 10;
                            Signs[i].hitbox.X -= 10;
                        }
                        for (int i = 0; i < Trolls.Count; i++)
                        {
                            Trolls[i]._position.X -= 10;
                            Trolls[i].hitbox.X -= 10;
                            for (int e = 0; e < Trolls[i].Bullets.Count; e++)
                            {
                                Trolls[i].Bullets[e].hitbox.X -= 10;
                                Trolls[i].Bullets[e]._position.X -= 10;
                            }
                        }
                        for (int i = 0; i < Bullet.Count; i++)
                        {
                            Bullet[i]._position.X -= 10;
                        }
                        for (int i = 0; i < PlayerBullets.Count; i++)
                        {
                            player._Bullet._position.X -= 10;
                        }
                        JetPackPowerUp._position.X -= 10;
                        JetPackPowerUp.hitbox.X -= 10;
                    }

                    if (player.hitbox.Intersects(JetPackPowerUp.hitbox))
                    {
                        Trumpjumpcount = true;
                        JetPackPowerUp._position.Y = -434;
                        JetPackPowerUp.hitbox.Y = -378;
                    }

                    if (RIGHT == false)
                    {
                        if (ks.IsKeyDown(Keys.Left) && movementAmount > 0)
                        {
                            player.effect = SpriteEffects.FlipHorizontally;
                            movementAmount--;
                            background._position.X += 10;
                            background2._position.X += 10;
                            for (int i = 0; i < Pol.Count; i++)
                            {
                                Pol[i]._position.X += 10;
                                Pol[i].hitbox = new Rectangle((int)Pol[i]._position.X, (int)Pol[i]._position.Y, Pol[i]._image.Width, Pol[i]._image.Height);
                            }
                            for (int i = 0; i < Blocks.Count; i++)
                            {
                                Blocks[i]._position.X += 10;
                                Blocks[i].hitbox = new Rectangle((int)Blocks[i]._position.X, (int)Blocks[i]._position.Y, Blocks[i]._image.Width, Blocks[i]._image.Height);
                            }
                            for (int i = 0; i < WPol.Count; i++)
                            {
                                WPol[i]._position.X += 10;
                                WPol[i].hitbox = new Rectangle((int)WPol[i]._position.X, (int)WPol[i]._position.Y, WPol[i]._image.Width, WPol[i]._image.Height);
                            }
                            for (int i = 0; i < Signs.Count; i++)
                            {
                                Signs[i]._position.X += 10;
                                Signs[i].hitbox.X += 10;
                            }
                            for (int i = 0; i < Trolls.Count; i++)
                            {
                                Trolls[i]._position.X += 10;
                                Trolls[i].hitbox.X += 10;
                                for (int e = 0; e < Trolls[i].Bullets.Count; e++)
                                {
                                    Trolls[i].Bullets[e].hitbox.X += 10;
                                    Trolls[i].Bullets[e]._position.X += 10;
                                }

                            }
                            for (int i = 0; i < Bullet.Count; i++)
                            {
                                Bullet[i]._position.X += 10;
                            }
                            for (int i = 0; i < PlayerBullets.Count; i++)
                            {
                                player._Bullet._position.X += 10;
                            }
                            JetPackPowerUp._position.X += 10;
                            JetPackPowerUp.hitbox.X += 10;
                        }
                    }


                    lastks = ks;
                    base.Update(gameTime);
                }
            }
        }


        protected override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();

            GraphicsDevice.Clear(Color.White);
            spriteBatch.DrawString(font, "X:" + ms.X + "Y:" + ms.Y, new Vector2(0, 0), Color.Black);
            //spriteBatch.DrawString(Content.Load<SpriteFont>("MOUSE"), player.jumpCount.ToString(), Vector2.Zero, Color.Black);
            //spriteBatch.DrawString(Content.Load<SpriteFont>("MOUSE"), "X:" + ms.X.ToString() + "Y:" + ms.Y.ToString(),new Vector2(0,0),Color.Black);
            background.Draw(spriteBatch);
            background2.Draw(spriteBatch);
            Back1.Draw(spriteBatch);
            Back2.Draw(spriteBatch);
            Back3.Draw(spriteBatch);
            Back4.Draw(spriteBatch);
            Back5.Draw(spriteBatch);
            Back6.Draw(spriteBatch);
            Back7.Draw(spriteBatch);
            Back8.Draw(spriteBatch);

            mouse.Draw(spriteBatch);
            for (int i = 0; i < Signs.Count; i++)
            {
                Signs[i].Draw(spriteBatch);


            }


            if (ShowLightning == true)
            {
                Whitepic.Draw(spriteBatch);
                lightning.Draw(spriteBatch);
            }
            for (int i = 0; i < Blocks.Count; i++)
            {
                Blocks[i].Draw(spriteBatch);

            }

            for (int i = 0; i < WPol.Count; i++)
            {
                WPol[i].Draw(spriteBatch);
            }

            for (int i = 0; i < Pol.Count; i++)
            {
                Pol[i].Draw(spriteBatch);
            }
            if (Showsmsg == true)
            {
                Smsg._position.X = Signs[0]._position.X;
                Smsg._position.Y = Signs[0]._position.Y - Smsg._image.Height;
                Smsg.Draw(spriteBatch);
            }
            if (Showsmsg1 == true)
            {
                Smsg1._position.X = Signs[1]._position.X;
                Smsg1._position.Y = Signs[1]._position.Y - Smsg1._image.Height;
                Smsg1.Draw(spriteBatch);
            }
            if (Showmsg2 == true)
            {
                Smsg2._position.X = Signs[2]._position.X;
                Smsg2._position.Y = Signs[2]._position.Y - Smsg2._image.Height;
                Smsg2.Draw(spriteBatch);
            }
            if (Showsmsg3 == true)
            {
                Smsg3._position.X = Signs[3]._position.X - Oldman1._image.Width;
                Smsg3._position.Y = Signs[3]._position.Y - Smsg3._image.Height;
                Smsg3.Draw(spriteBatch);
            }
            for (int i = 0; i < Flags.Count; i++)
            {
                Flags[i].Draw(spriteBatch);
            }
            for (int i = 0; i < Trolls.Count; i++)
            {
                Trolls[i].Draw(spriteBatch, font);
            }

            for (int i = 0; i < Bullet.Count; i++)
            {
                Bullet[i].Draw(spriteBatch);
            }
            for (int i = 0; i < Trolls.Count; i++)
            {
                Trolls[i].Draw(spriteBatch, font);
            }
            for (int i = 0; i < PlayerBullets.Count; i++)
            {
                PlayerBullets[i].Draw(spriteBatch);
            }
            JetPackPowerUp.Draw(spriteBatch);

            player.Draw(spriteBatch, font);





            base.Draw(gameTime);
            spriteBatch.End();
        }
    }
}
